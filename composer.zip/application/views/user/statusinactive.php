

<body>
<div class="container">
	<div class="row">
		<div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
			<div class="card card-signin my-5">
				<div class="card-body">
					<center>
						<img src="<?php echo base_url().'/assets/icons/inactive.png'?>">
						<h5 class="card-title text-center">In Active !</h5>
						<p>Your account is inactive</p>
						<p>Contact System Administrator to activate your account</p>
                        <a href="<?php echo base_url();?>login" class="btn btn-primary">Login</a>
					</center>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
