<h1>Dashboard View</h1>



<a href="<?php echo site_url('register') ?>">Complaint Add</a><br>
<a href="<?php echo site_url('userpanel/complaintList') ?>">Complaint List</a>