<h1>Dashboard View</h1>

<a href="<?php echo site_url('admin/admin/complaintList') ?>">Complaint List</a> <br>
<a href="<?php echo site_url('admin/admin/userList') ?>">User List</a>