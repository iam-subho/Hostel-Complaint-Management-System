<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$config['google']['client_id']        = '251239028926-2sjns4boqcbeind7bta740mra331caoo.apps.googleusercontent.com';
$config['google']['client_secret']    = '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';
$config['google']['redirect_uri']     = 'http://localhost/complaint/login/oauthgmail';
$config['google']['application_name'] = 'Public Grievance';
$config['google']['api_key']          = '';
$config['google']['scopes']           = array();